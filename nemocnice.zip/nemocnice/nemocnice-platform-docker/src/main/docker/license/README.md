# Enterprise License location

Put the Alfresco Enterprise license file in this directory.
It will then be copied into the ACS container in the  
$TOMCAT_DIR/WEB-INF/classes/alfresco/extension/license directory.  
 
