model["fromJS"] = "Hello from JS!";
